﻿function AddHeader() {
    var botDiv = document.querySelector('#webchat');
    var header = '<div class="wc-header" style="cursor: pointer;">' +
                    '<span> <img id="ChatIcon" style="vertical-align: middle; pading-right: 2px; padding-left: 2px; " src="/images/ChatIcon.png" height="25px" width="25px">' +
                    '&nbsp;&nbsp; <span style="vertical-align: middle">Travel Money Assistant </span>' +
                    '<img alt="imageIcon" src="/images/Arrow.png" id="TopDownArrow" style="transform: rotate(180deg); float: right; " height="20px" width="20px">'+
                    '</span >' +
                  '</div >';
    $(botDiv).prepend(header);

    botDiv.style.height = '30px';
    botDiv.style.width = '400px';
    document.querySelector('body').addEventListener('click', function (e) {

        e.target.matches = e.target.matches || e.target.msMatchesSelector;
        if (e.target.matches('.wc-header span') || e.target.matches('.wc-header') || e.target.matches('#TopDownArrow') || e.target.matches('#ChatIcon')) {


            // Animate section and set height of the chat bot
            if (botDiv.style.height === '580px') {
                $('#TopDownArrow').css({ 'transform': 'rotate(0deg)' });
                $('#webchat').animate({ height: '30px' }, 600);
            }
            else {
                $('#TopDownArrow').css({ 'transform': 'rotate(180deg)' });
                $('#webchat').animate({ height: '580px' }, 600);

            }

        }
    });
}

 