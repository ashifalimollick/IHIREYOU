﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using System.Web;
using System.IO;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using Microsoft.Azure;
using System.Configuration;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Http;
using DataAccessLayer;

namespace CognitiveSearch.UI.Controllers
{
    public class UploadController : Controller
    {
        static CloudBlobClient blobClient;
        const string blobContainerName = "resume-store";//"webappstoragedotnet-imagecontainer";
        static CloudBlobContainer blobContainer;
        private IConfiguration _configuration { get; set; }
        string connString;
        public UploadController(IConfiguration configuration)
        {
            _configuration = configuration;
            connString = _configuration.GetSection("SqlConnectionString")?.Value;
            //_docSearch = new DocumentSearchClient(configuration);
            //_idField = _configuration.GetSection("KeyField")?.Value;
            //_isPathBase64Encoded = (_configuration.GetSection("IsPathBase64Encoded")?.Value == "True");
        }
        public IActionResult Upload()
        {
            return View();
        }
        public async Task<ActionResult> Index()
        {
            try
            {
                //// Retrieve storage account information from connection string
                //// How to create a storage connection string - http://msdn.microsoft.com/en-us/library/azure/ee758697.aspx
                //CloudStorageAccount storageAccount = CloudStorageAccount.Parse(_configuration.GetSection("StorageConnectionString")?.Value);

                //// Create a blob client for interacting with the blob service.
                //blobClient = storageAccount.CreateCloudBlobClient();
                //blobContainer = blobClient.GetContainerReference(blobContainerName);
                ////await blobContainer.CreateIfNotExistsAsync(); //biswanath

                //await blobContainer.SetPermissionsAsync(new BlobContainerPermissions { PublicAccess = BlobContainerPublicAccessType.Blob });

                //// Gets all Cloud Block Blobs in the blobContainerName and passes them to teh view
                

                return View();
            }
            catch (Exception ex)
            {
                ViewData["message"] = ex.Message;
                ViewData["trace"] = ex.StackTrace;
                return View("Error");
            }
        }

        /// <summary> 
        /// Task<ActionResult> UploadAsync() 
        /// Documentation References:  
        /// - UploadFromFileAsync Method: https://msdn.microsoft.com/en-us/library/azure/microsoft.windowsazure.storage.blob.cloudpageblob.uploadfromfileasync.aspx
        /// </summary> 
        [HttpPost]
        public async Task<ActionResult> UploadAsync(string name,string mobile, string email)
        {
            try
            {
                var fileName = Request.Form.Files[0].FileName;
                var file = Request.Form.Files[0];

                int index = fileName.LastIndexOf('.');
                string extention = fileName.Substring(index, fileName.Length-index);

                CloudStorageAccount storageAccount = CloudStorageAccount.Parse(_configuration.GetSection("StorageConnectionString")?.Value);

                blobClient = storageAccount.CreateCloudBlobClient();
                blobContainer = blobClient.GetContainerReference(blobContainerName);

                await blobContainer.SetPermissionsAsync(new BlobContainerPermissions { PublicAccess = BlobContainerPublicAccessType.Blob });

               
                string blobFileName = name + "_" + mobile + extention;
                CloudBlockBlob blob = blobContainer.GetBlockBlobReference(blobFileName);

                using (Stream uploadFileStream = file.OpenReadStream())
                {
                    await blob.UploadFromStreamAsync(uploadFileStream);
                    uploadFileStream.Close();
                }

                DBLayer dbLayer = new DBLayer(connString);

                var result = dbLayer.InsertResume(name, mobile, blobFileName, email);
                TempData["SuccessMessage"] = "Resume Uploaded Successfully";
                return RedirectToAction("Upload");
            }
            catch (Exception ex)
            {
                ViewData["message"] = ex.Message;
                ViewData["trace"] = ex.StackTrace;
                return View("Error");
            }
        }

        /// <summary> 
        /// Task<ActionResult> DeleteImage(string name) 
        /// Documentation References:  
        /// - Delete Blobs: https://azure.microsoft.com/en-us/documentation/articles/storage-dotnet-how-to-use-blobs/#delete-blobs
        /// </summary> 
        [HttpPost]
        public async Task<ActionResult> DeleteImage(string name)
        {
            try
            {
                Uri uri = new Uri(name);
                string filename = Path.GetFileName(uri.LocalPath);

                var blob = blobContainer.GetBlockBlobReference(filename);
                await blob.DeleteIfExistsAsync();

                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                ViewData["message"] = ex.Message;
                ViewData["trace"] = ex.StackTrace;
                return View("Error");
            }
        }

       
        private string GetRandomBlobName(string filename)
        {
            string ext = Path.GetExtension(filename);
            return string.Format("{0:10}_{1}{2}", DateTime.Now.Ticks, Guid.NewGuid(), ext);
        }

    }
}