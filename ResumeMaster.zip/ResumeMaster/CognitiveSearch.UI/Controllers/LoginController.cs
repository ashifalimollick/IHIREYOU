﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CognitiveSearch.UI.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace CognitiveSearch.UI.Controllers
{
    public class LoginController : Controller
    {
        //public IActionResult Index()
        //{
        //    return View();
        //}

        IConfiguration _configuration;
        public LoginController(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        [HttpGet]
        [Route("")]
        [Route("Login/{ReturnUrl?}")]
        public IActionResult Login(string ReturnUrl = "")
        {
            var login = new LoginViewModel();
            login.ReturnUrl = ReturnUrl;
            return View(login);
        }

        [HttpPost]
        [Route("")]
        [Route("Login/{ReturnUrl?}")]
        public async Task<IActionResult> Login(LoginViewModel login)
        {
            //
            if (ModelState.IsValid)
            {
                 
                if (login.UserName=="admin" && login.Password=="password@123")
                {

                    return RedirectToAction("Index", "Home");
                }
                else
                    return View();

            }
            else
            {
                return View();
            }

        }
    }
}