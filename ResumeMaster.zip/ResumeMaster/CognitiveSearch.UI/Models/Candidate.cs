﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CognitiveSearch.UI.Models
{
    public class Candidate
    {
        public string UserName { get; set; }
        public string Email { get; set; }
    }
}
