﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CognitiveSearch.UI.Models
{
    public class InterviewModel
    {
        public string toemail { get; set; }
        public string candidatename { get; set; }
        public string interviewdate { get; set; }
        public string interviewtime { get; set; }
        public string interviewtype { get; set; }
        public string token { get; set; }

    }
}
