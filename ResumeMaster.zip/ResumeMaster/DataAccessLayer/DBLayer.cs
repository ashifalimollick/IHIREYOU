﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace DataAccessLayer
{
    public class DBLayer
    {
        static string connectionString = "";
        public DBLayer(String _connection)
        {
            connectionString = _connection;
        }
        public Boolean InsertResume(string name,string mobile,string filename,string email)
        {
            using (var sqlConn = new SqlConnection(connectionString))
            {
                using (var sqlCmd = new SqlCommand("SP_InsertResume", sqlConn))
                {
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.Add("@UserName", SqlDbType.VarChar).Value = name;
                    sqlCmd.Parameters.Add("@MobileNumber", SqlDbType.VarChar).Value = mobile;
                    sqlCmd.Parameters.Add("@ResumeFileName", SqlDbType.VarChar).Value = filename;
                    sqlCmd.Parameters.Add("@Email", SqlDbType.VarChar).Value = email;

                    sqlConn.Open();
                    var result = sqlCmd.ExecuteScalar();
                    return true;
                }
            }
        }

        public string SearchResume(string mobile)
        {
            CandidateModel cand = new CandidateModel();
            using (var sqlConn = new SqlConnection(connectionString))
            {
                using (var sqlCmd = new SqlCommand("SP_SearchResume", sqlConn))
                {
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.Add("@MobileNumber", SqlDbType.VarChar).Value = mobile;

                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlConn.Open();

                    SqlDataReader reader = sqlCmd.ExecuteReader();

                    while (reader.Read())
                    {

                        cand.UserName = reader["UserName"].ToString();
                        cand.Email = reader["Email"].ToString();
                    }
                    reader.Close();
                    sqlConn.Close();
                }
            }

            return cand.UserName+":"+cand.Email;
        }

        public Boolean ScheduleInterview(string mobile,string date,string time, string type, string token)
        {
            using (var sqlConn = new SqlConnection(connectionString))
            {
                using (var sqlCmd = new SqlCommand("SP_ScheduleInterview", sqlConn))
                {
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.Add("@MobileNumber", SqlDbType.VarChar).Value = mobile;
                    sqlCmd.Parameters.Add("@ScheduleDate", SqlDbType.VarChar).Value = date;
                    sqlCmd.Parameters.Add("@ScheduleTime", SqlDbType.VarChar).Value = time;
                    sqlCmd.Parameters.Add("@Type", SqlDbType.VarChar).Value = type;
                    sqlCmd.Parameters.Add("@Token", SqlDbType.VarChar).Value = token;
                    sqlConn.Open();
                    var result = sqlCmd.ExecuteScalar();
                    return true;
                }
            }
        }
    }
}
